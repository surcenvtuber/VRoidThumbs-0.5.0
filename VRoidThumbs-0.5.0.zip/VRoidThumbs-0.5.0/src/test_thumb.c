/* End-to-end harness: registers the DLL, drives it through COM exactly the way
   Explorer does (IInitializeWithStream -> IThumbnailProvider), dumps the
   resulting HBITMAP to a .bmp so the pixels can be checked. */
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#include <windows.h>
#include <shlwapi.h>
#include <objbase.h>
#include <stdio.h>

static const GUID CLSID_VRoidThumb =
    {0x731825bd, 0x1ba4, 0x4a7f, {0xbd, 0x96, 0xe5, 0x7d, 0x47, 0x7e, 0x18, 0xd1}};
static const GUID IID_ThumbProv =
    {0xe357fccd, 0xa995, 0x4576, {0xb0, 0x1f, 0x23, 0x46, 0x30, 0x15, 0x4e, 0x96}};
static const GUID IID_InitStream =
    {0xb824b49d, 0x22ac, 0x4161, {0xac, 0x8a, 0x99, 0x16, 0xe8, 0xfa, 0x3f, 0x7f}};

typedef struct IInitWithStreamVtbl {
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(void *, REFIID, void **);
    ULONG (STDMETHODCALLTYPE *AddRef)(void *);
    ULONG (STDMETHODCALLTYPE *Release)(void *);
    HRESULT (STDMETHODCALLTYPE *Initialize)(void *, IStream *, DWORD);
} IInitWithStreamVtbl;
typedef struct { IInitWithStreamVtbl *v; } IInitWithStreamX;

typedef struct IThumbVtbl {
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(void *, REFIID, void **);
    ULONG (STDMETHODCALLTYPE *AddRef)(void *);
    ULONG (STDMETHODCALLTYPE *Release)(void *);
    HRESULT (STDMETHODCALLTYPE *GetThumbnail)(void *, UINT, HBITMAP *, int *);
} IThumbVtbl;
typedef struct { IThumbVtbl *v; } IThumbX;

static void reg(const wchar_t *sub, const wchar_t *name, const wchar_t *val) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, sub, 0, NULL, 0, KEY_WRITE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, name, 0, REG_SZ, (const BYTE *)val,
                       (DWORD)((wcslen(val) + 1) * sizeof(wchar_t)));
        RegCloseKey(k);
    }
}

static int save_bmp(HBITMAP hbm, const char *path) {
    BITMAP bm;
    BITMAPFILEHEADER fh;
    BITMAPINFOHEADER ih;
    FILE *f;
    DWORD sz;
    if (!GetObject(hbm, sizeof(bm), &bm)) return 0;
    if (!bm.bmBits) return 0;
    sz = (DWORD)(bm.bmWidth * 4 * abs(bm.bmHeight));
    ZeroMemory(&ih, sizeof(ih));
    ih.biSize = sizeof(ih);
    ih.biWidth = bm.bmWidth;
    ih.biHeight = -abs(bm.bmHeight);
    ih.biPlanes = 1;
    ih.biBitCount = 32;
    ih.biCompression = BI_RGB;
    ZeroMemory(&fh, sizeof(fh));
    fh.bfType = 0x4D42;
    fh.bfOffBits = sizeof(fh) + sizeof(ih);
    fh.bfSize = fh.bfOffBits + sz;
    f = fopen(path, "wb");
    if (!f) return 0;
    fwrite(&fh, 1, sizeof(fh), f);
    fwrite(&ih, 1, sizeof(ih), f);
    fwrite(bm.bmBits, 1, sz, f);
    fclose(f);
    printf("   bitmap %ldx%ld written to %s\n", bm.bmWidth, abs(bm.bmHeight), path);
    return 1;
}

int wmain(int argc, wchar_t **argv) {
    HRESULT hr;
    IUnknown *unk = NULL;
    IInitWithStreamX *init = NULL;
    IThumbX *tp = NULL;
    IStream *stm = NULL;
    HBITMAP hbm = NULL;
    int alpha = -1;
    UINT cx = 256;
    char out[512];

    if (argc < 3) { printf("usage: test_thumb <dll> <file> [cx] [out.bmp]\n"); return 2; }
    if (argc >= 4) cx = (UINT)_wtoi(argv[3]);
    wcstombs(out, argc >= 5 ? argv[4] : L"out.bmp", sizeof(out));

    reg(L"Software\\Classes\\CLSID\\{731825BD-1BA4-4A7F-BD96-E57D477E18D1}", NULL, L"VRoid Thumbnail Provider");
    reg(L"Software\\Classes\\CLSID\\{731825BD-1BA4-4A7F-BD96-E57D477E18D1}\\InprocServer32", NULL, argv[1]);
    reg(L"Software\\Classes\\CLSID\\{731825BD-1BA4-4A7F-BD96-E57D477E18D1}\\InprocServer32", L"ThreadingModel", L"Apartment");

    hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    printf("CoInitializeEx      0x%08lX\n", (unsigned long)hr);

    hr = CoCreateInstance(&CLSID_VRoidThumb, NULL, CLSCTX_INPROC_SERVER, &IID_IUnknown, (void **)&unk);
    printf("CoCreateInstance    0x%08lX\n", (unsigned long)hr);
    if (FAILED(hr)) return 1;

    hr = unk->lpVtbl->QueryInterface(unk, &IID_InitStream, (void **)&init);
    printf("QI IInitWithStream  0x%08lX\n", (unsigned long)hr);
    if (FAILED(hr)) return 1;

    hr = SHCreateStreamOnFileEx(argv[2], STGM_READ | STGM_SHARE_DENY_WRITE, 0, FALSE, NULL, &stm);
    printf("open file           0x%08lX\n", (unsigned long)hr);
    if (FAILED(hr)) return 1;

    hr = init->v->Initialize(init, stm, 0);
    printf("Initialize          0x%08lX\n", (unsigned long)hr);
    if (FAILED(hr)) return 1;

    hr = init->v->QueryInterface(init, &IID_ThumbProv, (void **)&tp);
    printf("QI IThumbnailProv   0x%08lX\n", (unsigned long)hr);
    if (FAILED(hr)) return 1;

    hr = tp->v->GetThumbnail(tp, cx, &hbm, &alpha);
    printf("GetThumbnail(%u)   0x%08lX  alpha=%d  hbmp=%p\n",
           cx, (unsigned long)hr, alpha, (void *)hbm);
    if (SUCCEEDED(hr) && hbm) {
        save_bmp(hbm, out);
        DeleteObject(hbm);
    }
    tp->v->Release(tp);
    init->v->Release(init);
    stm->lpVtbl->Release(stm);
    unk->lpVtbl->Release(unk);
    CoUninitialize();
    return SUCCEEDED(hr) ? 0 : 1;
}
