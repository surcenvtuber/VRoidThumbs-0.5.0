/* vglb.c - pull the VRM meta thumbnail out of a .vrm (glTF binary) container.
   VRM 0.x : extensions.VRM.meta.texture      -> textures[i].source -> images[j]
   VRM 1.0 : extensions.VRMC_vrm.meta.thumbnailImage -> images[j]
   images[j].bufferView -> bufferViews[k] -> bytes inside the GLB BIN chunk.

   Contains a tiny read-only JSON walker: it skips values it does not need
   instead of building a token tree, so a 50 MB model costs one JSON read. */

#include "vzip.h"
#include "vjson.h"
#include <stdlib.h>
#include <string.h>

#define GLB_MAGIC 0x46546C67u  /* "glTF" */
#define CHUNK_JSON 0x4E4F534Au /* "JSON" */
#define CHUNK_BIN  0x004E4942u /* "BIN\0" */
#define VG_MAX_JSON (48u * 1024u * 1024u)

static unsigned g32(const unsigned char *p) {
    return (unsigned)p[0] | ((unsigned)p[1] << 8) | ((unsigned)p[2] << 16) | ((unsigned)p[3] << 24);
}

/* ---- extractor ---- */

int vg_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                     unsigned char **out, unsigned *outlen, int *kind) {
    unsigned char hdr[12], ch[8];
    unsigned long long off, jsonoff = 0, binoff = 0, total;
    unsigned jsonlen = 0, binlen = 0;
    char *js = NULL;
    int n, root, ext, meta, node, ok = 0;
    long imgIdx = -1, bv = -1, byteOff = 0, byteLen = 0;
    unsigned char *buf = NULL;

    if (!out || !outlen || !kind) return 0;
    *out = NULL; *outlen = 0; *kind = VZ_KIND_UNKNOWN;
    if (filesize < 20) return 0;
    if (!rd(ctx, 0, hdr, 12)) return 0;
    if (g32(hdr) != GLB_MAGIC) return 0;

    total = g32(hdr + 8);
    if (total > filesize || total < 20) total = filesize;

    for (off = 12; off + 8 <= total;) {
        unsigned clen, ctype;
        if (!rd(ctx, off, ch, 8)) return 0;
        clen = g32(ch);
        ctype = g32(ch + 4);
        if (off + 8 + (unsigned long long)clen > total) break;
        if (ctype == CHUNK_JSON && !jsonlen) { jsonoff = off + 8; jsonlen = clen; }
        else if (ctype == CHUNK_BIN && !binlen) { binoff = off + 8; binlen = clen; }
        off += 8 + clen;
        if (clen % 4) off += 4 - (clen % 4);   /* chunks are 4-byte aligned */
    }
    if (!jsonlen || jsonlen > VG_MAX_JSON) return 0;

    js = (char *)malloc(jsonlen);
    if (!js) return 0;
    if (!rd(ctx, jsonoff, js, jsonlen)) { free(js); return 0; }
    n = (int)jsonlen;

    root = j_ws(js, 0, n);
    ext = j_member(js, root, n, "extensions");
    if (ext < 0) { free(js); return 0; }

    /* VRM 1.0 first */
    node = j_member(js, ext, n, "VRMC_vrm");
    if (node >= 0) {
        meta = j_member(js, node, n, "meta");
        if (meta >= 0) {
            int t = j_member(js, meta, n, "thumbnailImage");
            if (t >= 0) j_int(js, t, n, &imgIdx);
        }
    }
    /* VRM 0.x: meta.texture is an index into textures[] */
    if (imgIdx < 0) {
        node = j_member(js, ext, n, "VRM");
        if (node >= 0) {
            meta = j_member(js, node, n, "meta");
            if (meta >= 0) {
                int t = j_member(js, meta, n, "texture");
                long texIdx = -1;
                if (t >= 0 && j_int(js, t, n, &texIdx) && texIdx >= 0) {
                    int arr = j_member(js, root, n, "textures");
                    int e = (arr >= 0) ? j_elem(js, arr, n, texIdx) : -1;
                    int src = (e >= 0) ? j_member(js, e, n, "source") : -1;
                    if (src >= 0) j_int(js, src, n, &imgIdx);
                }
            }
        }
    }
    if (imgIdx < 0) { free(js); return 0; }

    {
        int arr = j_member(js, root, n, "images");
        int e = (arr >= 0) ? j_elem(js, arr, n, imgIdx) : -1;
        int b = (e >= 0) ? j_member(js, e, n, "bufferView") : -1;
        if (b < 0 || !j_int(js, b, n, &bv) || bv < 0) { free(js); return 0; }
    }
    {
        int arr = j_member(js, root, n, "bufferViews");
        int e = (arr >= 0) ? j_elem(js, arr, n, bv) : -1;
        int o, l;
        if (e < 0) { free(js); return 0; }
        o = j_member(js, e, n, "byteOffset");
        l = j_member(js, e, n, "byteLength");
        if (o >= 0) j_int(js, o, n, &byteOff);
        if (l < 0 || !j_int(js, l, n, &byteLen)) { free(js); return 0; }
    }
    free(js);

    if (byteLen <= 0 || byteOff < 0) return 0;
    if ((unsigned long)byteLen > VZ_MAX_THUMB) return 0;
    if (!binlen) return 0;
    if ((unsigned long long)byteOff + (unsigned long long)byteLen > binlen) return 0;

    buf = (unsigned char *)malloc((unsigned)byteLen);
    if (!buf) return 0;
    if (!rd(ctx, binoff + (unsigned long long)byteOff, buf, (unsigned)byteLen)) { free(buf); return 0; }

    if (byteLen >= 4 && buf[0] == 0x89 && buf[1] == 'P' && buf[2] == 'N' && buf[3] == 'G')
        *kind = VZ_KIND_PNG;
    else if (byteLen >= 3 && buf[0] == 0xFF && buf[1] == 0xD8 && buf[2] == 0xFF)
        *kind = VZ_KIND_JPEG;
    else
        *kind = VZ_KIND_JPEG;   /* let WIC decide; treat as opaque */

    *out = buf;
    *outlen = (unsigned)byteLen;
    ok = 1;
    return ok;
}
