/* VRoid Thumbnails - Windows Explorer thumbnail provider for
   .vroid and .vroidcustomitem (both are ZIP containers with a baked thumbnail).

   Handles two container shapes, chosen by sniffing the first bytes:
     ZIP  -> .vroid, .vroidcustomitem, .xwear, .xavatar
     glTF -> .vrm (VRM 0.x and 1.0 meta thumbnails)
   Only the container index and one image are ever read. */

#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlwapi.h>
#include <objbase.h>
#include <thumbcache.h>
#include <wincodec.h>
#include <new>

extern "C" {
#include "vzip.h"
}

// {731825BD-1BA4-4A7F-BD96-E57D477E18D1}
static const GUID CLSID_VRoidThumb =
    {0x731825bd, 0x1ba4, 0x4a7f, {0xbd, 0x96, 0xe5, 0x7d, 0x47, 0x7e, 0x18, 0xd1}};

/* mingw-w64's import libs don't carry all of these IIDs; define them locally. */
static const GUID IID_ThumbProv =
    {0xe357fccd, 0xa995, 0x4576, {0xb0, 0x1f, 0x23, 0x46, 0x30, 0x15, 0x4e, 0x96}};
static const GUID IID_InitStream =
    {0xb824b49d, 0x22ac, 0x4161, {0xac, 0x8a, 0x99, 0x16, 0xe8, 0xfa, 0x3f, 0x7f}};
static const GUID CLSID_WICFactory =
    {0xcacaf262, 0x9370, 0x4615, {0xa1, 0x3b, 0x9f, 0x55, 0x39, 0xda, 0x4c, 0x0a}};
static const GUID IID_WICFactory =
    {0xec5ec8a9, 0xc395, 0x4314, {0x9c, 0x77, 0x54, 0xd7, 0xa9, 0x35, 0xff, 0x70}};

static LONG g_refs = 0;
static HINSTANCE g_inst = NULL;

static void mod_ref(bool add) { InterlockedExchangeAdd(&g_refs, add ? 1 : -1); }

/* ---------- IStream adapter for vzip ---------- */

struct StreamCtx { IStream *s; };

static int stream_read(void *ctx, unsigned long long off, void *buf, unsigned len) {
    StreamCtx *c = (StreamCtx *)ctx;
    LARGE_INTEGER li;
    ULONG done = 0, total = 0;
    li.QuadPart = (LONGLONG)off;
    if (FAILED(c->s->Seek(li, STREAM_SEEK_SET, NULL))) return 0;
    while (total < len) {
        if (FAILED(c->s->Read((BYTE *)buf + total, len - total, &done)) || done == 0) return 0;
        total += done;
    }
    return 1;
}

/* ---------- provider ---------- */

class CVRoidThumb : public IInitializeWithStream, public IThumbnailProvider {
public:
    CVRoidThumb() : m_ref(1), m_stream(NULL) { mod_ref(true); }

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID riid, void **ppv) {
        if (!ppv) return E_POINTER;
        if (IsEqualIID(riid, IID_IUnknown) || IsEqualIID(riid, IID_InitStream))
            *ppv = static_cast<IInitializeWithStream *>(this);
        else if (IsEqualIID(riid, IID_ThumbProv))
            *ppv = static_cast<IThumbnailProvider *>(this);
        else { *ppv = NULL; return E_NOINTERFACE; }
        AddRef();
        return S_OK;
    }
    IFACEMETHODIMP_(ULONG) AddRef() { return InterlockedIncrement(&m_ref); }
    IFACEMETHODIMP_(ULONG) Release() {
        LONG r = InterlockedDecrement(&m_ref);
        if (r == 0) delete this;
        return r;
    }

    // IInitializeWithStream
    IFACEMETHODIMP Initialize(IStream *pstm, DWORD) {
        if (m_stream) return HRESULT_FROM_WIN32(ERROR_ALREADY_INITIALIZED);
        if (!pstm) return E_INVALIDARG;
        m_stream = pstm;
        m_stream->AddRef();
        return S_OK;
    }

    // IThumbnailProvider
    IFACEMETHODIMP GetThumbnail(UINT cx, HBITMAP *phbmp, WTS_ALPHATYPE *pdwAlpha);

private:
    ~CVRoidThumb() {
        if (m_stream) m_stream->Release();
        mod_ref(false);
    }
    LONG m_ref;
    IStream *m_stream;
};

static HRESULT WicToHBITMAP(IWICBitmapSource *src, UINT cx, HBITMAP *phbmp) {
    HRESULT hr;
    UINT w = 0, h = 0;
    IWICImagingFactory *fac = NULL;
    IWICBitmapScaler *scaler = NULL;
    IWICFormatConverter *conv = NULL;
    IWICBitmapSource *cur = src;
    BITMAPINFO bi;
    void *bits = NULL;
    HBITMAP hbm = NULL;

    hr = src->GetSize(&w, &h);
    if (FAILED(hr) || !w || !h) return FAILED(hr) ? hr : E_FAIL;

    hr = CoCreateInstance(CLSID_WICFactory, NULL, CLSCTX_INPROC_SERVER,
                          IID_WICFactory, (void **)&fac);
    if (FAILED(hr)) return hr;

    /* Fit inside cx x cx, never upscale. */
    if (w > cx || h > cx) {
        UINT nw, nh;
        if (w >= h) { nw = cx; nh = (UINT)((double)h * cx / w + 0.5); }
        else        { nh = cx; nw = (UINT)((double)w * cx / h + 0.5); }
        if (!nw) nw = 1;
        if (!nh) nh = 1;
        hr = fac->CreateBitmapScaler(&scaler);
        if (SUCCEEDED(hr)) hr = scaler->Initialize(src, nw, nh, WICBitmapInterpolationModeFant);
        if (SUCCEEDED(hr)) { cur = scaler; w = nw; h = nh; }
        if (FAILED(hr)) goto done;
    }

    hr = fac->CreateFormatConverter(&conv);
    if (FAILED(hr)) goto done;
    hr = conv->Initialize(cur, GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone,
                          NULL, 0.0, WICBitmapPaletteTypeCustom);
    if (FAILED(hr)) goto done;

    ZeroMemory(&bi, sizeof(bi));
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = (LONG)w;
    bi.bmiHeader.biHeight = -(LONG)h;   /* top-down */
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    hbm = CreateDIBSection(NULL, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    if (!hbm || !bits) { hr = E_OUTOFMEMORY; goto done; }

    hr = conv->CopyPixels(NULL, w * 4, w * 4 * h, (BYTE *)bits);
    if (FAILED(hr)) { DeleteObject(hbm); hbm = NULL; goto done; }

    *phbmp = hbm;
    hbm = NULL;
    hr = S_OK;

done:
    if (hbm) DeleteObject(hbm);
    if (conv) conv->Release();
    if (scaler) scaler->Release();
    if (fac) fac->Release();
    return hr;
}

IFACEMETHODIMP CVRoidThumb::GetThumbnail(UINT cx, HBITMAP *phbmp, WTS_ALPHATYPE *pdwAlpha) {
    if (!phbmp || !pdwAlpha) return E_POINTER;
    *phbmp = NULL;
    *pdwAlpha = WTSAT_UNKNOWN;
    if (!m_stream) return E_UNEXPECTED;
    if (cx == 0) cx = 256;

    STATSTG st;
    ZeroMemory(&st, sizeof(st));
    if (FAILED(m_stream->Stat(&st, STATFLAG_NONAME))) return E_FAIL;
    if (st.pwcsName) CoTaskMemFree(st.pwcsName);

    StreamCtx ctx;
    ctx.s = m_stream;
    unsigned char *data = NULL;
    unsigned len = 0;
    int kind = 0;
    if (!v_extract_thumb(&ctx, stream_read, (unsigned long long)st.cbSize.QuadPart,
                          &data, &len, &kind))
        return E_FAIL;   /* no thumbnail -> Explorer falls back to the default icon */

    IStream *mem = SHCreateMemStream(data, len);
    free(data);
    if (!mem) return E_OUTOFMEMORY;

    IWICImagingFactory *fac = NULL;
    IWICBitmapDecoder *dec = NULL;
    IWICBitmapFrameDecode *frame = NULL;
    HRESULT hr = CoCreateInstance(CLSID_WICFactory, NULL, CLSCTX_INPROC_SERVER,
                                  IID_WICFactory, (void **)&fac);
    if (SUCCEEDED(hr))
        hr = fac->CreateDecoderFromStream(mem, NULL, WICDecodeMetadataCacheOnDemand, &dec);
    if (SUCCEEDED(hr)) hr = dec->GetFrame(0, &frame);
    if (SUCCEEDED(hr)) hr = WicToHBITMAP(frame, cx, phbmp);
    if (SUCCEEDED(hr)) *pdwAlpha = (kind == VZ_KIND_PNG) ? WTSAT_ARGB : WTSAT_RGB;

    if (frame) frame->Release();
    if (dec) dec->Release();
    if (fac) fac->Release();
    mem->Release();
    return hr;
}

/* ---------- class factory ---------- */

class CFactory : public IClassFactory {
public:
    CFactory() : m_ref(1) { mod_ref(true); }
    IFACEMETHODIMP QueryInterface(REFIID riid, void **ppv) {
        if (!ppv) return E_POINTER;
        if (IsEqualIID(riid, IID_IUnknown) || IsEqualIID(riid, IID_IClassFactory)) {
            *ppv = static_cast<IClassFactory *>(this);
            AddRef();
            return S_OK;
        }
        *ppv = NULL;
        return E_NOINTERFACE;
    }
    IFACEMETHODIMP_(ULONG) AddRef() { return InterlockedIncrement(&m_ref); }
    IFACEMETHODIMP_(ULONG) Release() {
        LONG r = InterlockedDecrement(&m_ref);
        if (r == 0) delete this;
        return r;
    }
    IFACEMETHODIMP CreateInstance(IUnknown *outer, REFIID riid, void **ppv) {
        if (outer) return CLASS_E_NOAGGREGATION;
        CVRoidThumb *p = new (std::nothrow) CVRoidThumb();
        if (!p) return E_OUTOFMEMORY;
        HRESULT hr = p->QueryInterface(riid, ppv);
        p->Release();
        return hr;
    }
    IFACEMETHODIMP LockServer(BOOL lock) { mod_ref(lock != FALSE); return S_OK; }
private:
    ~CFactory() { mod_ref(false); }
    LONG m_ref;
};

extern "C" {

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_inst = inst;
        DisableThreadLibraryCalls(inst);
    }
    return TRUE;
}

__declspec(dllexport) HRESULT __stdcall DllGetClassObject(REFCLSID rclsid, REFIID riid, void **ppv) {
    if (!ppv) return E_POINTER;
    *ppv = NULL;
    if (!IsEqualCLSID(rclsid, CLSID_VRoidThumb)) return CLASS_E_CLASSNOTAVAILABLE;
    CFactory *f = new (std::nothrow) CFactory();
    if (!f) return E_OUTOFMEMORY;
    HRESULT hr = f->QueryInterface(riid, ppv);
    f->Release();
    return hr;
}

__declspec(dllexport) HRESULT __stdcall DllCanUnloadNow(void) {
    return (g_refs == 0) ? S_OK : S_FALSE;
}

} /* extern "C" */
