/* vjson.h - tiny read-only JSON walker shared by the GLB and XItem.json paths.
   Everything is an offset into one in-memory buffer; nothing is allocated. */
#ifndef VJSON_H
#define VJSON_H

#ifdef __cplusplus
extern "C" {
#endif

int j_ws(const char *s, int i, int n);
int j_str(const char *s, int i, int n);                       /* '"' -> past close */
int j_val(const char *s, int i, int n);                       /* any value -> past end */
int j_member(const char *s, int i, int n, const char *key);   /* '{' -> value offset */
int j_elem(const char *s, int i, int n, long idx);            /* '[' -> element offset */
int j_arr_first(const char *s, int i, int n);                 /* '[' -> first element  */
int j_arr_next(const char *s, int i, int n);                  /* element -> next, or -1 */
int j_int(const char *s, int i, int n, long *out);
int j_bool(const char *s, int i, int n, int *out);
int j_strval(const char *s, int i, int n, char *out, int cap); /* copies raw contents */

#ifdef __cplusplus
}
#endif
#endif
