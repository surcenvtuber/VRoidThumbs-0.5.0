/* VRoid Thumbnails - installer / uninstaller.
   Single .exe: the provider DLL is embedded as an RCDATA resource.
   Everything is written under HKCU, so no administrator rights are needed. */

#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <stdio.h>

#define APP_VER          L"0.5.0"
#define CLSID_STR        L"{731825BD-1BA4-4A7F-BD96-E57D477E18D1}"
#define THUMB_HANDLER    L"{E357FCCD-A995-4576-B01F-234630154E96}"
#define DLL_NAME         L"VRoidThumbs.dll"
#define INSTALL_DIRNAME  L"VRoidThumbs"

#define IDC_LANG      1001
#define IDC_DESC      1002
#define IDC_STATUS    1003
#define IDC_CHK       1004
#define IDC_INSTALL   1005
#define IDC_UNINSTALL 1006
#define IDC_CLOSE     1007
#define IDC_NOTE      1008

enum { L_ZH = 0, L_EN, L_JA, L_KO, L_COUNT };

typedef struct {
    const wchar_t *title, *desc, *on, *off, *install, *uninstall, *close,
        *chk, *note, *okin, *okun, *failin, *failun, *busy, *already, *notinst;
} Strings;

static const Strings S[L_COUNT] = {
    { /* zh */
      L"VRoid 缩略图 " APP_VER,
      L"在资源管理器里直接显示 .vroid / .vroidcustomitem / .vrm / .xwear / .xavatar 的预览图。\n"
      L"预览图是文件里已经存好的小图，读取很快，不会像 PSD 补丁那样拖慢文件夹。",
      L"状态：已安装 ✓",
      L"状态：未安装",
      L"安装", L"卸载", L"关闭",
      L"顺便清理缩略图缓存（注意：会关闭你所有已打开的文件夹窗口）",
      L"仅安装到当前用户，不需要管理员权限，随时可以卸载还原。",
      L"安装完成。打开放 VRoid 文件的文件夹，视图切成中/大图标即可。\n以前看过的文件夹若仍显示旧图标，再运行一次本程序并勾选清理缓存。",
      L"已卸载，注册表已还原。",
      L"安装失败：", L"卸载失败：",
      L"文件正在被使用，请勾选「重启资源管理器」后重试。",
      L"已经安装过了，将覆盖为当前版本。",
      L"当前未安装。" },
    { /* en */
      L"VRoid Thumbnails " APP_VER,
      L"Previews for .vroid, .vroidcustomitem, .vrm, .xwear and .xavatar files.\n"
      L"The preview is already stored inside the file, so reading it is cheap - unlike\n"
      L"PSD thumbnail patches, this will not slow your folders down.",
      L"Status: installed \u2713",
      L"Status: not installed",
      L"Install", L"Uninstall", L"Close",
      L"Also clear the thumbnail cache (this closes every open Explorer window)",
      L"Installs for the current user only. No administrator rights needed.",
      L"Done. Open a folder with VRoid files and switch to medium/large icons.\nIf an already-visited folder still shows old icons, run this again with the cache option ticked.",
      L"Uninstalled. All registry entries were removed.",
      L"Install failed: ", L"Uninstall failed: ",
      L"The file is in use. Tick \"Restart Explorer\" and try again.",
      L"Already installed - it will be replaced with this version.",
      L"Not installed." },
    { /* ja */
      L"VRoid サムネイル " APP_VER,
      L".vroid / .vroidcustomitem / .vrm / .xwear / .xavatar のサムネイルを表示します。\n"
      L"ファイル内に保存済みの小さな画像を読むだけなので、PSD 用パッチのように\n"
      L"フォルダーが重くなることはありません。",
      L"状態：インストール済み ✓",
      L"状態：未インストール",
      L"インストール", L"アンインストール", L"閉じる",
      L"サムネイルキャッシュも消去する（開いているフォルダーが全て閉じます）",
      L"現在のユーザーのみにインストールします。管理者権限は不要です。",
      L"完了しました。VRoid ファイルのフォルダーを開き、中／大アイコン表示にしてください。\n以前開いたフォルダーが古いアイコンのままの場合は、キャッシュ消去にチェックして再実行してください。",
      L"アンインストールしました。レジストリも元に戻しました。",
      L"インストール失敗：", L"アンインストール失敗：",
      L"ファイルが使用中です。「エクスプローラーを再起動」にチェックして再試行してください。",
      L"すでにインストール済みです。このバージョンで上書きします。",
      L"インストールされていません。" },
    { /* ko */
      L"VRoid 썸네일 " APP_VER,
      L".vroid / .vroidcustomitem / .vrm / .xwear / .xavatar 파일의 미리보기를 표시합니다.\n"
      L"파일 안에 이미 저장된 작은 이미지를 읽을 뿐이라, PSD 패치처럼 폴더가\n"
      L"느려지지 않습니다.",
      L"상태: 설치됨 ✓",
      L"상태: 설치되지 않음",
      L"설치", L"제거", L"닫기",
      L"썸네일 캐시도 삭제 (열려 있는 모든 탐색기 창이 닫힙니다)",
      L"현재 사용자에게만 설치되며 관리자 권한이 필요 없습니다.",
      L"완료되었습니다. VRoid 파일 폴더를 열고 보통/큰 아이콘 보기로 전환하세요.\n이전에 열었던 폴더가 예전 아이콘이면 캐시 삭제를 체크하고 다시 실행하세요.",
      L"제거되었습니다. 레지스트리도 복원되었습니다.",
      L"설치 실패: ", L"제거 실패: ",
      L"파일이 사용 중입니다. \"탐색기 다시 시작\"을 선택한 뒤 다시 시도하세요.",
      L"이미 설치되어 있습니다. 이 버전으로 덮어씁니다.",
      L"설치되어 있지 않습니다." }
};

static int g_lang = L_EN;
static HWND g_wnd, g_hDesc, g_hStatus, g_hChk, g_hInstall, g_hUninstall, g_hClose, g_hLang, g_hNote;
static HFONT g_font;
static int g_dpi = 96;
static int SC(int v) { return MulDiv(v, g_dpi, 96); }

/* ---------- paths ---------- */

static void install_dir(wchar_t *out, size_t n) {
    wchar_t base[MAX_PATH];
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, base))) base[0] = 0;
    _snwprintf(out, n, L"%s\\%s", base, INSTALL_DIRNAME);
    out[n - 1] = 0;
}
static void dll_path(wchar_t *out, size_t n) {
    wchar_t d[MAX_PATH];
    install_dir(d, MAX_PATH);
    _snwprintf(out, n, L"%s\\%s", d, DLL_NAME);
    out[n - 1] = 0;
}

/* ---------- registry ---------- */

static LONG set_str(const wchar_t *sub, const wchar_t *name, const wchar_t *val) {
    HKEY k;
    LONG r = RegCreateKeyExW(HKEY_CURRENT_USER, sub, 0, NULL, 0, KEY_WRITE, NULL, &k, NULL);
    if (r != ERROR_SUCCESS) return r;
    r = RegSetValueExW(k, name, 0, REG_SZ, (const BYTE *)val,
                       (DWORD)((wcslen(val) + 1) * sizeof(wchar_t)));
    RegCloseKey(k);
    return r;
}

static int is_installed(void) {
    HKEY k;
    wchar_t dll[MAX_PATH];
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"Software\\Classes\\CLSID\\" CLSID_STR L"\\InprocServer32",
                      0, KEY_READ, &k) != ERROR_SUCCESS)
        return 0;
    RegCloseKey(k);
    dll_path(dll, MAX_PATH);
    return GetFileAttributesW(dll) != INVALID_FILE_ATTRIBUTES;
}

static const wchar_t *const kExts[] = {
    L".vroid", L".vroidcustomitem", L".vrm", L".xwear", L".xavatar"
};
#define EXT_COUNT (sizeof(kExts) / sizeof(kExts[0]))

static LONG write_registry(const wchar_t *dll) {
    LONG r;
    size_t i;
    if ((r = set_str(L"Software\\Classes\\CLSID\\" CLSID_STR, NULL,
                     L"VRoid Thumbnail Provider")) != ERROR_SUCCESS) return r;
    if ((r = set_str(L"Software\\Classes\\CLSID\\" CLSID_STR, L"AppID", CLSID_STR)) != ERROR_SUCCESS) return r;
    if ((r = set_str(L"Software\\Classes\\CLSID\\" CLSID_STR L"\\InprocServer32", NULL, dll)) != ERROR_SUCCESS) return r;
    if ((r = set_str(L"Software\\Classes\\CLSID\\" CLSID_STR L"\\InprocServer32",
                     L"ThreadingModel", L"Apartment")) != ERROR_SUCCESS) return r;
    /* Run inside the COM surrogate so a crash can never take Explorer with it. */
    if ((r = set_str(L"Software\\Classes\\AppID\\" CLSID_STR, L"DllSurrogate", L"")) != ERROR_SUCCESS) return r;
    for (i = 0; i < EXT_COUNT; i++) {
        wchar_t key[256];
        _snwprintf(key, 256, L"Software\\Classes\\%s\\ShellEx\\%s", kExts[i], THUMB_HANDLER);
        key[255] = 0;
        if ((r = set_str(key, NULL, CLSID_STR)) != ERROR_SUCCESS) return r;
    }
    return ERROR_SUCCESS;
}

static void clear_registry(void) {
    size_t i;
    for (i = 0; i < EXT_COUNT; i++) {
        wchar_t key[256];
        _snwprintf(key, 256, L"Software\\Classes\\%s\\ShellEx\\%s", kExts[i], THUMB_HANDLER);
        key[255] = 0;
        SHDeleteKeyW(HKEY_CURRENT_USER, key);
    }
    SHDeleteKeyW(HKEY_CURRENT_USER, L"Software\\Classes\\CLSID\\" CLSID_STR);
    SHDeleteKeyW(HKEY_CURRENT_USER, L"Software\\Classes\\AppID\\" CLSID_STR);
    /* The .vroid / .vroidcustomitem keys themselves are left alone: other
       software may rely on them, and an empty ShellEx key is harmless. */
}

/* ---------- explorer / cache ---------- */

static void run_wait(const wchar_t *cmd, DWORD ms) {
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    wchar_t buf[512];
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    wcsncpy(buf, cmd, 511); buf[511] = 0;
    if (CreateProcessW(NULL, buf, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, ms);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
}

static void restart_explorer_clear_cache(void) {
    wchar_t base[MAX_PATH], pat[MAX_PATH], f[MAX_PATH], exp[MAX_PATH];
    WIN32_FIND_DATAW fd;
    HANDLE h;

    run_wait(L"taskkill.exe /F /IM explorer.exe", 8000);
    Sleep(800);

    if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, base))) {
        _snwprintf(pat, MAX_PATH, L"%s\\Microsoft\\Windows\\Explorer\\thumbcache_*.db", base);
        h = FindFirstFileW(pat, &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                _snwprintf(f, MAX_PATH, L"%s\\Microsoft\\Windows\\Explorer\\%s", base, fd.cFileName);
                DeleteFileW(f);   /* locked entries are simply skipped */
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
    }
    if (GetWindowsDirectoryW(exp, MAX_PATH)) {
        wcsncat(exp, L"\\explorer.exe", MAX_PATH - wcslen(exp) - 1);
        {
            STARTUPINFOW si;
            PROCESS_INFORMATION pi;
            ZeroMemory(&si, sizeof(si));
            si.cb = sizeof(si);
            if (CreateProcessW(exp, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
                CloseHandle(pi.hProcess);
                CloseHandle(pi.hThread);
            }
        }
    }
}

/* ---------- install / uninstall ---------- */

static int write_embedded_dll(const wchar_t *path, DWORD *err) {
    HRSRC res = FindResourceW(NULL, MAKEINTRESOURCEW(1), RT_RCDATA);
    HGLOBAL g;
    const void *p;
    DWORD sz, written = 0;
    HANDLE h;
    if (!res) { *err = GetLastError(); return 0; }
    sz = SizeofResource(NULL, res);
    g = LoadResource(NULL, res);
    if (!g || !sz) { *err = GetLastError(); return 0; }
    p = LockResource(g);
    if (!p) { *err = GetLastError(); return 0; }

    h = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        /* Most likely loaded by a running DllHost: park the old copy aside. */
        wchar_t old[MAX_PATH];
        _snwprintf(old, MAX_PATH, L"%s.old%lu", path, GetTickCount());
        if (MoveFileExW(path, old, MOVEFILE_REPLACE_EXISTING)) {
            MoveFileExW(old, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
            h = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        }
        if (h == INVALID_HANDLE_VALUE) { *err = GetLastError(); return 0; }
    }
    if (!WriteFile(h, p, sz, &written, NULL) || written != sz) {
        *err = GetLastError();
        CloseHandle(h);
        return 0;
    }
    CloseHandle(h);
    return 1;
}

static void msg(const wchar_t *text, UINT icon) {
    MessageBoxW(g_wnd, text, S[g_lang].title, MB_OK | icon);
}

static void refresh_ui(void) {
    const Strings *s = &S[g_lang];
    SetWindowTextW(g_wnd, s->title);
    SetWindowTextW(g_hDesc, s->desc);
    SetWindowTextW(g_hStatus, is_installed() ? s->on : s->off);
    SetWindowTextW(g_hChk, s->chk);
    SetWindowTextW(g_hNote, s->note);
    SetWindowTextW(g_hInstall, s->install);
    SetWindowTextW(g_hUninstall, s->uninstall);
    SetWindowTextW(g_hClose, s->close);
}

static void do_install(void) {
    wchar_t dir[MAX_PATH], dll[MAX_PATH], buf[512];
    DWORD err = 0;
    LONG r;
    int cache = (int)SendMessageW(g_hChk, BM_GETCHECK, 0, 0);

    install_dir(dir, MAX_PATH);
    dll_path(dll, MAX_PATH);
    CreateDirectoryW(dir, NULL);

    if (!write_embedded_dll(dll, &err)) {
        _snwprintf(buf, 512, L"%s%lu\n%s", S[g_lang].failin, err, S[g_lang].busy);
        msg(buf, MB_ICONERROR);
        return;
    }
    r = write_registry(dll);
    if (r != ERROR_SUCCESS) {
        _snwprintf(buf, 512, L"%s%ld", S[g_lang].failin, r);
        msg(buf, MB_ICONERROR);
        return;
    }
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, NULL, NULL);
    if (cache == BST_CHECKED) restart_explorer_clear_cache();
    refresh_ui();
    msg(S[g_lang].okin, MB_ICONINFORMATION);
}

static void do_uninstall(void) {
    wchar_t dir[MAX_PATH], dll[MAX_PATH];
    int cache = (int)SendMessageW(g_hChk, BM_GETCHECK, 0, 0);
    if (!is_installed()) {
        clear_registry();
        refresh_ui();
        msg(S[g_lang].notinst, MB_ICONINFORMATION);
        return;
    }
    install_dir(dir, MAX_PATH);
    dll_path(dll, MAX_PATH);

    clear_registry();
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, NULL, NULL);
    if (cache == BST_CHECKED) restart_explorer_clear_cache();

    if (!DeleteFileW(dll))
        MoveFileExW(dll, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
    RemoveDirectoryW(dir);
    refresh_ui();
    msg(S[g_lang].okun, MB_ICONINFORMATION);
}

/* ---------- window ---------- */

static HWND mk(const wchar_t *cls, const wchar_t *text, DWORD style,
               int x, int y, int w, int h, HWND parent, int id) {
    HWND c = CreateWindowExW(0, cls, text, WS_CHILD | WS_VISIBLE | style,
                             SC(x), SC(y), SC(w), SC(h), parent, (HMENU)(INT_PTR)id,
                             GetModuleHandleW(NULL), NULL);
    SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE);
    return c;
}

static LRESULT CALLBACK proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        int i;
        static const wchar_t *names[L_COUNT] = { L"中文", L"English", L"日本語", L"한국어" };
        g_hLang = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, 360, 12, 110, 200, h, IDC_LANG);
        for (i = 0; i < L_COUNT; i++)
            SendMessageW(g_hLang, CB_ADDSTRING, 0, (LPARAM)names[i]);
        SendMessageW(g_hLang, CB_SETCURSEL, g_lang, 0);

        g_hDesc = mk(L"STATIC", L"", 0, 16, 46, 456, 62, h, IDC_DESC);
        g_hStatus = mk(L"STATIC", L"", 0, 16, 116, 456, 20, h, IDC_STATUS);
        g_hChk = mk(L"BUTTON", L"", BS_AUTOCHECKBOX | BS_MULTILINE | WS_TABSTOP, 16, 142, 456, 36, h, IDC_CHK);
        g_hNote = mk(L"STATIC", L"", 0, 16, 184, 456, 20, h, IDC_NOTE);
        g_hInstall = mk(L"BUTTON", L"", BS_DEFPUSHBUTTON | WS_TABSTOP, 16, 214, 140, 34, h, IDC_INSTALL);
        g_hUninstall = mk(L"BUTTON", L"", WS_TABSTOP, 168, 214, 140, 34, h, IDC_UNINSTALL);
        g_hClose = mk(L"BUTTON", L"", WS_TABSTOP, 332, 214, 140, 34, h, IDC_CLOSE);
        SendMessageW(g_hChk, BM_SETCHECK, BST_UNCHECKED, 0);  /* opt-in: it closes folders */
        refresh_ui();
        return 0;
    }
    case WM_COMMAND:
        switch (LOWORD(w)) {
        case IDC_LANG:
            if (HIWORD(w) == CBN_SELCHANGE) {
                g_lang = (int)SendMessageW(g_hLang, CB_GETCURSEL, 0, 0);
                refresh_ui();
            }
            return 0;
        case IDC_INSTALL:   do_install();   return 0;
        case IDC_UNINSTALL: do_uninstall(); return 0;
        case IDC_CLOSE:     DestroyWindow(h); return 0;
        }
        return 0;
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, LPWSTR cmd, int show) {
    WNDCLASSEXW wc;
    MSG msgq;
    HDC dc;
    RECT rc;
    int w, hgt;
    LANGID ui = GetUserDefaultUILanguage();
    (void)prev;

    switch (PRIMARYLANGID(ui)) {
    case LANG_CHINESE:  g_lang = L_ZH; break;
    case LANG_JAPANESE: g_lang = L_JA; break;
    case LANG_KOREAN:   g_lang = L_KO; break;
    default:            g_lang = L_EN; break;
    }

    dc = GetDC(NULL);
    g_dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(NULL, dc);
    g_font = CreateFontW(-MulDiv(10, g_dpi, 72), 0, 0, 0, FW_NORMAL, 0, 0, 0,
                         DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                         CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");

    ZeroMemory(&wc, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = proc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"VRoidThumbsSetup";
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(2));
    wc.hIconSm = wc.hIcon;
    RegisterClassExW(&wc);

    rc.left = 0; rc.top = 0; rc.right = SC(488); rc.bottom = SC(266);
    AdjustWindowRect(&rc, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, FALSE);
    w = rc.right - rc.left;
    hgt = rc.bottom - rc.top;

    g_wnd = CreateWindowExW(0, wc.lpszClassName, S[g_lang].title,
                            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                            CW_USEDEFAULT, CW_USEDEFAULT, w, hgt, NULL, NULL, inst, NULL);
    if (!g_wnd) return 1;
    ShowWindow(g_wnd, show);
    UpdateWindow(g_wnd);

    /* "/uninstall" on the command line for scripted removal. */
    if (cmd && wcsstr(cmd, L"/uninstall")) do_uninstall();

    while (GetMessageW(&msgq, NULL, 0, 0) > 0) {
        if (!IsDialogMessageW(g_wnd, &msgq)) {
            TranslateMessage(&msgq);
            DispatchMessageW(&msgq);
        }
    }
    DeleteObject(g_font);
    return 0;
}
