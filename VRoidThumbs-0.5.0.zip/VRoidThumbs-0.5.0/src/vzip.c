#include "vzip.h"
#include "vjson.h"
#include "miniz_tinfl.h"
#include <stdlib.h>
#include <string.h>

#define VZ_MAX_ENTRIES 4096
#define VZ_NAME_MAX    240
#define VZ_MAX_JSON    (8u * 1024u * 1024u)

typedef struct {
    char name[VZ_NAME_MAX];
    unsigned method, csize, usize;
    unsigned long long lho;
} vz_ent;

static unsigned rd16(const unsigned char *p) { return p[0] | (p[1] << 8); }
static unsigned rd32(const unsigned char *p) {
    return (unsigned)p[0] | ((unsigned)p[1] << 8) | ((unsigned)p[2] << 16) | ((unsigned)p[3] << 24);
}
static unsigned long long rd64(const unsigned char *p) {
    return (unsigned long long)rd32(p) | ((unsigned long long)rd32(p + 4) << 32);
}

static char lc(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c; }

static int ci_ends_with(const char *s, unsigned slen, const char *suffix) {
    unsigned n = (unsigned)strlen(suffix), i;
    if (slen < n) return 0;
    s += slen - n;
    for (i = 0; i < n; i++)
        if (lc(s[i]) != lc(suffix[i])) return 0;
    return 1;
}

static int ci_contains(const char *hay, const char *needle) {
    unsigned hl = (unsigned)strlen(hay), nl = (unsigned)strlen(needle), i, j;
    if (!nl || nl > hl) return 0;
    for (i = 0; i + nl <= hl; i++) {
        for (j = 0; j < nl; j++)
            if (lc(hay[i + j]) != lc(needle[j])) break;
        if (j == nl) return 1;
    }
    return 0;
}

static const char *basename_of(const char *s) {
    const char *b = s;
    for (; *s; s++)
        if (*s == '/' || *s == '\\') b = s + 1;
    return b;
}

static int is_image(const char *name, int *kind) {
    unsigned len = (unsigned)strlen(name);
    if (ci_ends_with(name, len, ".png")) { *kind = VZ_KIND_PNG; return 1; }
    if (ci_ends_with(name, len, ".jpg") || ci_ends_with(name, len, ".jpeg")) {
        *kind = VZ_KIND_JPEG;
        return 1;
    }
    return 0;
}

/* How good a name is as a thumbnail. Lower is better; 0 = not a candidate. */
static int thumb_rank(const char *name) {
    unsigned len = (unsigned)strlen(name);
    const char *base = basename_of(name);
    unsigned dirlen = (unsigned)(base - name);
    if (ci_ends_with(name, len, "thumbnails/thumbnail.png")) return 1;
    if (ci_ends_with(name, len, "thumbnails/thumbnail.jpg")) return 2;
    if (ci_ends_with(name, len, "thumbnails/thumbnail.jpeg")) return 3;
    if (dirlen) {
        char dir[VZ_NAME_MAX];
        unsigned d = dirlen - 1;   /* drop the separator */
        if (d < VZ_NAME_MAX) {
            memcpy(dir, name, d);
            dir[d] = 0;
            if (ci_ends_with(dir, d, "thumbnails") || ci_ends_with(dir, d, "thumbnail")) return 4;
        }
    }
    if (ci_contains(base, "thumb") || ci_contains(base, "preview") || ci_contains(base, "icon"))
        return 5;
    return 0;
}

/* ---------- container index ---------- */

static int read_entries(void *ctx, vz_read_fn rd, unsigned long long filesize,
                        vz_ent **out_ents, unsigned *out_count) {
    unsigned char tail[66000];
    unsigned taillen, cdsize = 0, nent = 0, pos = 0, count = 0, i;
    unsigned long long cdoff = 0;
    long eocd = -1;
    unsigned char *cd = NULL;
    vz_ent *ents = NULL;

    if (filesize < 22) return 0;
    taillen = (unsigned)(filesize < sizeof(tail) ? filesize : sizeof(tail));
    if (!rd(ctx, filesize - taillen, tail, taillen)) return 0;

    for (i = taillen - 22 + 1; i-- > 0;)
        if (tail[i] == 0x50 && tail[i + 1] == 0x4B && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
            eocd = (long)i;
            break;
        }
    if (eocd < 0) return 0;

    nent = rd16(tail + eocd + 10);
    cdsize = rd32(tail + eocd + 12);
    cdoff = rd32(tail + eocd + 16);

    if (nent == 0xFFFF || cdsize == 0xFFFFFFFFu || cdoff == 0xFFFFFFFFu) {
        long loc = eocd - 20;
        unsigned char z64[56];
        unsigned long long z64off, n, s;
        if (loc < 0) return 0;
        if (!(tail[loc] == 0x50 && tail[loc + 1] == 0x4B && tail[loc + 2] == 0x06 && tail[loc + 3] == 0x07))
            return 0;
        z64off = rd64(tail + loc + 8);
        if (z64off + 56 > filesize || !rd(ctx, z64off, z64, 56)) return 0;
        if (!(z64[0] == 0x50 && z64[1] == 0x4B && z64[2] == 0x06 && z64[3] == 0x06)) return 0;
        n = rd64(z64 + 32);
        s = rd64(z64 + 40);
        cdoff = rd64(z64 + 48);
        if (n > VZ_MAX_ENTRIES || s > VZ_MAX_CDIR) return 0;
        cdsize = (unsigned)s;
    }

    if (!cdsize || cdsize > VZ_MAX_CDIR || cdoff + cdsize > filesize) return 0;
    cd = (unsigned char *)malloc(cdsize);
    if (!cd) return 0;
    if (!rd(ctx, cdoff, cd, cdsize)) { free(cd); return 0; }

    ents = (vz_ent *)calloc(VZ_MAX_ENTRIES, sizeof(vz_ent));
    if (!ents) { free(cd); return 0; }

    while (pos + 46 <= cdsize && count < VZ_MAX_ENTRIES) {
        unsigned namelen, extralen, commentlen;
        vz_ent *e = &ents[count];
        if (rd32(cd + pos) != 0x02014b50u) break;
        namelen = rd16(cd + pos + 28);
        extralen = rd16(cd + pos + 30);
        commentlen = rd16(cd + pos + 32);
        if (pos + 46 + namelen + extralen + commentlen > cdsize) break;

        e->method = rd16(cd + pos + 10);
        e->csize = rd32(cd + pos + 20);
        e->usize = rd32(cd + pos + 24);
        e->lho = rd32(cd + pos + 42);
        if (namelen < VZ_NAME_MAX && e->lho != 0xFFFFFFFFull && e->csize != 0xFFFFFFFFu) {
            memcpy(e->name, cd + pos + 46, namelen);
            e->name[namelen] = 0;
            count++;
        }
        pos += 46 + namelen + extralen + commentlen;
    }
    free(cd);
    if (!count) { free(ents); return 0; }
    *out_ents = ents;
    *out_count = count;
    return 1;
}

static int extract_entry(void *ctx, vz_read_fn rd, unsigned long long filesize,
                         const vz_ent *e, unsigned char **out, unsigned *outlen) {
    unsigned char lh[30], *comp = NULL, *plain = NULL;
    unsigned long long dataoff;

    if (!e->usize || e->usize > VZ_MAX_THUMB || e->csize > VZ_MAX_THUMB) return 0;
    if (e->method != 0 && e->method != 8) return 0;
    if (e->lho + 30 > filesize || !rd(ctx, e->lho, lh, 30)) return 0;
    if (rd32(lh) != 0x04034b50u) return 0;
    dataoff = e->lho + 30 + rd16(lh + 26) + rd16(lh + 28);
    if (dataoff + e->csize > filesize) return 0;

    if (e->method == 0) {
        plain = (unsigned char *)malloc(e->csize ? e->csize : 1);
        if (!plain) return 0;
        if (!rd(ctx, dataoff, plain, e->csize)) { free(plain); return 0; }
        *out = plain;
        *outlen = e->csize;
        return 1;
    }
    comp = (unsigned char *)malloc(e->csize ? e->csize : 1);
    if (!comp) return 0;
    if (!rd(ctx, dataoff, comp, e->csize)) { free(comp); return 0; }
    plain = (unsigned char *)malloc(e->usize);
    if (!plain) { free(comp); return 0; }
    {
        size_t st = tinfl_decompress_mem_to_mem(plain, (size_t)e->usize,
                                                comp, (size_t)e->csize, 0);
        free(comp);
        if (st == TINFL_DECOMPRESS_MEM_TO_MEM_FAILED || st == 0) { free(plain); return 0; }
        *outlen = (unsigned)st;
    }
    *out = plain;
    return 1;
}

/* ---------- .xwear / .xavatar ----------

   These formats carry no thumbnail. Body\XItem.json\XItem.json lists every
   material and which texture GUID sits in which shader slot, so rather than
   guessing by file size we take a _MainTex (base colour) and never a normal
   map, MatCap, emission or shade map. Materials are tiered by name so a
   costume wins over skin on an avatar. */

#define TIER_NONE 9

typedef struct { char guid[64]; int tier; } MainTexPick;

/* Slots that can never be a base colour. A texture bound to any of these in
   ANY material is refused even if another material also calls it _MainTex -
   VRoid-external items (Blender accessories) routinely wire a MatCap into
   _MainTex, and a shaded sphere is a worse thumbnail than none at all. */
static int is_non_base_slot(const char *p) {
    static const char *const bad[] = {
        "_BumpMap", "_NormalMap", "_SphereAdd", "_MatcapTex", "_MatCap",
        "_EmissionMap", "_EmissiveTex", "_RimTexture", "_RimMap",
        "_OutlineWidthTexture", "_UvAnimMaskTexture", "_ShadingGradeTexture"
    };
    unsigned i;
    for (i = 0; i < sizeof(bad) / sizeof(bad[0]); i++)
        if (strcmp(p, bad[i]) == 0) return 1;
    return 0;
}

/* Same judgement from the texture's own name, for files where the offending
   slot never appears (e.g. a lone material whose only map is a MatCap). */
static int name_is_non_base(const char *n) {
    static const char *const bad[] = {
        "matcap", "sphere", "normal", "bump", "emission", "outline"
    };
    unsigned i;
    if (n[0] == '_' && n[1] == '_') return 1;   /* __white__, __flatnormal__ */
    for (i = 0; i < sizeof(bad) / sizeof(bad[0]); i++)
        if (ci_contains(n, bad[i])) return 1;
    return 0;
}

#define VZ_MAX_BLACK 128

static int collect_blacklist(const char *js, int n, char black[][64], int cap) {
    int root = j_ws(js, 0, n), mats, m, count = 0;
    if (root < 0) return 0;
    mats = j_member(js, root, n, "XResourceMaterials");
    if (mats < 0) return 0;
    for (m = j_arr_first(js, mats, n); m >= 0 && count < cap; m = j_arr_next(js, m, n)) {
        int props = j_member(js, m, n, "ShaderProperties"), p;
        if (props < 0) continue;
        for (p = j_arr_first(js, props, n); p >= 0 && count < cap; p = j_arr_next(js, p, n)) {
            char pname[64], guid[64];
            int pn = j_member(js, p, n, "PropertyName"), tg;
            if (pn < 0 || !j_strval(js, pn, n, pname, sizeof(pname))) continue;
            if (!is_non_base_slot(pname)) continue;
            tg = j_member(js, p, n, "TextureGuid");
            if (tg < 0 || !j_strval(js, tg, n, guid, sizeof(guid))) continue;
            memcpy(black[count], guid, sizeof(guid));
            count++;
        }
    }
    return count;
}

/* Only materials that name themselves as garment / hair / body parts qualify.
   Third-party accessories (Blender-authored bracelets, wings, hats) use free-
   form material names and abstract art as their base colour, so there is no
   metadata that distinguishes "the item's appearance" from "a MatCap sphere".
   Rather than guess from pixels, those get no thumbnail at all. */
static int mat_tier(const char *name) {
    if (ci_contains(name, "CLOTH") || ci_contains(name, "Onepiece") ||
        ci_contains(name, "Tops") || ci_contains(name, "Bottoms") ||
        ci_contains(name, "Dress") || ci_contains(name, "Skirt") ||
        ci_contains(name, "Costume") || ci_contains(name, "Outfit") ||
        ci_contains(name, "Shoes") || ci_contains(name, "Socks")) return 0;
    if (ci_contains(name, "HAIR")) return 1;
    if (ci_contains(name, "FACE")) return 2;
    if (ci_contains(name, "SKIN") || ci_contains(name, "Body")) return 3;
    return TIER_NONE;
}

static int collect_maintex(const char *js, int n, MainTexPick *picks, int cap) {
    int root = j_ws(js, 0, n), mats, m, count = 0;
    if (root < 0) return 0;
    mats = j_member(js, root, n, "XResourceMaterials");
    if (mats < 0) return 0;

    for (m = j_arr_first(js, mats, n); m >= 0 && count < cap; m = j_arr_next(js, m, n)) {
        char mname[128];
        int props, p, tier, nm;
        nm = j_member(js, m, n, "Name");
        if (nm < 0 || !j_strval(js, nm, n, mname, sizeof(mname))) mname[0] = 0;
        tier = mat_tier(mname);

        props = j_member(js, m, n, "ShaderProperties");
        if (props < 0) continue;
        for (p = j_arr_first(js, props, n); p >= 0; p = j_arr_next(js, p, n)) {
            char pname[64], guid[64];
            int pn = j_member(js, p, n, "PropertyName"), tg;
            if (pn < 0 || !j_strval(js, pn, n, pname, sizeof(pname))) continue;
            if (strcmp(pname, "_MainTex") != 0) continue;
            tg = j_member(js, p, n, "TextureGuid");
            if (tg < 0 || !j_strval(js, tg, n, guid, sizeof(guid))) continue;
            memcpy(picks[count].guid, guid, sizeof(guid));
            picks[count].tier = tier;
            count++;
            break;
        }
    }
    return count;
}

/* Placeholders (__white__, __flatnormal__) and anything flagged as a normal
   map are dropped even if a material binds them to _MainTex. */
static int guid_is_usable(const char *js, int n, const char *guid) {
    int root = j_ws(js, 0, n), arr, t;
    if (root < 0) return 1;
    arr = j_member(js, root, n, "XResourceTextures");
    if (arr < 0) return 1;
    for (t = j_arr_first(js, arr, n); t >= 0; t = j_arr_next(js, t, n)) {
        char g[64], nm[128];
        int gi = j_member(js, t, n, "Guid"), ni, is;
        if (gi < 0 || !j_strval(js, gi, n, g, sizeof(g))) continue;
        if (strcmp(g, guid) != 0) continue;
        ni = j_member(js, t, n, "Name");
        if (ni >= 0 && j_strval(js, ni, n, nm, sizeof(nm)) && name_is_non_base(nm))
            return 0;
        is = j_member(js, t, n, "TextureImportSettings");
        if (is >= 0) {
            int inorm = j_member(js, is, n, "isNormal"), b = 0;
            if (inorm >= 0 && j_bool(js, inorm, n, &b) && b) return 0;
        }
        return 1;
    }
    return 1;
}

static int pick_xwear_texture(void *ctx, vz_read_fn rd, unsigned long long filesize,
                              vz_ent *ents, unsigned count, unsigned *out_index) {
    unsigned i;
    int best = -1, best_tier = 99, npick, k;
    unsigned best_size = 0, jslen = 0;
    unsigned char *js = NULL;
    MainTexPick picks[64];
    char black[VZ_MAX_BLACK][64];
    int nblack;

    for (i = 0; i < count; i++)
        if (ci_ends_with(ents[i].name, (unsigned)strlen(ents[i].name), "XItem.json")) break;
    if (i == count || ents[i].usize > VZ_MAX_JSON) return 0;
    if (!extract_entry(ctx, rd, filesize, &ents[i], &js, &jslen)) return 0;

    nblack = collect_blacklist((const char *)js, (int)jslen, black, VZ_MAX_BLACK);
    npick = collect_maintex((const char *)js, (int)jslen, picks, 64);
    for (k = 0; k < npick; k++) {
        unsigned j;
        int b, skip = 0;
        for (b = 0; b < nblack; b++)
            if (strcmp(black[b], picks[k].guid) == 0) { skip = 1; break; }
        if (skip) continue;
        if (picks[k].tier >= TIER_NONE) continue;   /* not a garment/body material */
        if (!guid_is_usable((const char *)js, (int)jslen, picks[k].guid)) continue;
        for (j = 0; j < count; j++) {
            int kind;
            if (!is_image(ents[j].name, &kind)) continue;
            if (!ci_contains(ents[j].name, picks[k].guid)) continue;
            if (picks[k].tier < best_tier ||
                (picks[k].tier == best_tier && ents[j].usize > best_size)) {
                best = (int)j;
                best_tier = picks[k].tier;
                best_size = ents[j].usize;
            }
        }
    }
    free(js);
    if (best < 0) return 0;
    *out_index = (unsigned)best;
    return 1;
}

/* ---------- entry point ---------- */

int vz_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                     unsigned char **out, unsigned *outlen, int *kind) {
    vz_ent *ents = NULL;
    unsigned count = 0, i, chosen = 0;
    int have = 0, best_rank = 0, k;

    if (!out || !outlen || !kind) return 0;
    *out = NULL; *outlen = 0; *kind = VZ_KIND_UNKNOWN;
    if (!read_entries(ctx, rd, filesize, &ents, &count)) return 0;

    /* 1. a real, purpose-made thumbnail */
    for (i = 0; i < count; i++) {
        int r;
        if (!is_image(ents[i].name, &k)) continue;
        if (!ents[i].usize || ents[i].usize > VZ_MAX_THUMB) continue;
        r = thumb_rank(ents[i].name);
        if (r && (!best_rank || r < best_rank)) { best_rank = r; chosen = i; have = 1; }
    }

    /* 2. .xwear / .xavatar: the base-colour texture named by XItem.json */
    if (!have) have = pick_xwear_texture(ctx, rd, filesize, ents, count, &chosen);

    if (!have) { free(ents); return 0; }

    is_image(ents[chosen].name, kind);
    if (!extract_entry(ctx, rd, filesize, &ents[chosen], out, outlen)) {
        free(ents);
        return 0;
    }
    free(ents);
    return 1;
}

int v_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                    unsigned char **out, unsigned *outlen, int *kind) {
    unsigned char magic[4];
    if (!out || !outlen || !kind) return 0;
    *out = NULL; *outlen = 0; *kind = VZ_KIND_UNKNOWN;
    if (filesize < 16) return 0;
    if (!rd(ctx, 0, magic, 4)) return 0;
    if (magic[0] == 'P' && magic[1] == 'K')
        return vz_extract_thumb(ctx, rd, filesize, out, outlen, kind);
    if (magic[0] == 'g' && magic[1] == 'l' && magic[2] == 'T' && magic[3] == 'F')
        return vg_extract_thumb(ctx, rd, filesize, out, outlen, kind);
    return 0;
}
