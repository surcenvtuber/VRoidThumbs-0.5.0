/* vjson.c - tiny read-only JSON walker. Skips values it does not need instead
   of building a token tree, so a large glTF JSON chunk costs one pass. */

#include "vjson.h"
#include <string.h>


int j_ws(const char *s, int i, int n) {
    while (i < n && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++;
    return i;
}

int j_str(const char *s, int i, int n) { /* s[i]=='"' -> after closing quote */
    if (i >= n || s[i] != '"') return -1;
    for (i++; i < n; i++) {
        if (s[i] == '\\') { i++; continue; }
        if (s[i] == '"') return i + 1;
    }
    return -1;
}

int j_val(const char *s, int i, int n) {
    i = j_ws(s, i, n);
    if (i >= n) return -1;
    if (s[i] == '"') return j_str(s, i, n);
    if (s[i] == '{' || s[i] == '[') {
        char open = s[i], close = (open == '{') ? '}' : ']';
        int depth = 0;
        for (; i < n; i++) {
            if (s[i] == '"') {
                int e = j_str(s, i, n);
                if (e < 0) return -1;
                i = e - 1;
                continue;
            }
            if (s[i] == open) depth++;
            else if (s[i] == close) { depth--; if (!depth) return i + 1; }
        }
        return -1;
    }
    while (i < n && s[i] != ',' && s[i] != '}' && s[i] != ']' &&
           s[i] != ' ' && s[i] != '\n' && s[i] != '\r' && s[i] != '\t') i++;
    return i;
}

/* s[i] must be '{'. Returns offset of the value for `key`, or -1. */
int j_member(const char *s, int i, int n, const char *key) {
    unsigned klen = (unsigned)strlen(key);
    i = j_ws(s, i, n);
    if (i >= n || s[i] != '{') return -1;
    i++;
    for (;;) {
        int ks, ke, v;
        i = j_ws(s, i, n);
        if (i >= n) return -1;
        if (s[i] == '}') return -1;
        if (s[i] != '"') return -1;
        ks = i + 1;
        ke = j_str(s, i, n);
        if (ke < 0) return -1;
        i = j_ws(s, ke, n);
        if (i >= n || s[i] != ':') return -1;
        v = j_ws(s, i + 1, n);
        if ((unsigned)(ke - 1 - ks) == klen && strncmp(s + ks, key, klen) == 0) return v;
        i = j_val(s, v, n);
        if (i < 0) return -1;
        i = j_ws(s, i, n);
        if (i < n && s[i] == ',') i++;
    }
}

/* s[i] must be '['. Returns offset of element `idx`, or -1. */
int j_elem(const char *s, int i, int n, long idx) {
    long k = 0;
    i = j_ws(s, i, n);
    if (i >= n || s[i] != '[') return -1;
    i++;
    for (;;) {
        i = j_ws(s, i, n);
        if (i >= n || s[i] == ']') return -1;
        if (k == idx) return i;
        i = j_val(s, i, n);
        if (i < 0) return -1;
        i = j_ws(s, i, n);
        if (i < n && s[i] == ',') i++;
        k++;
    }
}

int j_int(const char *s, int i, int n, long *out) {
    long sign = 1, v = 0;
    int any = 0;
    i = j_ws(s, i, n);
    if (i >= n) return 0;
    if (s[i] == '-') { sign = -1; i++; }
    while (i < n && s[i] >= '0' && s[i] <= '9') { v = v * 10 + (s[i] - '0'); i++; any = 1; }
    if (!any) return 0;
    *out = sign * v;
    return 1;
}


int j_arr_first(const char *s, int i, int n) {
    i = j_ws(s, i, n);
    if (i >= n || s[i] != '[') return -1;
    i = j_ws(s, i + 1, n);
    if (i >= n || s[i] == ']') return -1;
    return i;
}

int j_arr_next(const char *s, int i, int n) {
    i = j_val(s, i, n);
    if (i < 0) return -1;
    i = j_ws(s, i, n);
    if (i >= n || s[i] != ',') return -1;
    i = j_ws(s, i + 1, n);
    if (i >= n || s[i] == ']') return -1;
    return i;
}

int j_bool(const char *s, int i, int n, int *out) {
    i = j_ws(s, i, n);
    if (i + 4 <= n && strncmp(s + i, "true", 4) == 0) { *out = 1; return 1; }
    if (i + 5 <= n && strncmp(s + i, "false", 5) == 0) { *out = 0; return 1; }
    return 0;
}

int j_strval(const char *s, int i, int n, char *out, int cap) {
    int e, len;
    i = j_ws(s, i, n);
    if (i >= n || s[i] != '"') return 0;
    e = j_str(s, i, n);
    if (e < 0) return 0;
    len = e - 1 - (i + 1);
    if (len < 0 || len >= cap) return 0;
    memcpy(out, s + i + 1, (size_t)len);
    out[len] = 0;
    return 1;
}
