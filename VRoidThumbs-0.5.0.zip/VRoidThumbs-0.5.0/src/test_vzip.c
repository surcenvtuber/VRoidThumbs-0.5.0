#include "vzip.h"
#include <stdio.h>
#include <stdlib.h>

static int rd(void *ctx, unsigned long long off, void *buf, unsigned len) {
    FILE *f = (FILE *)ctx;
    if (fseek(f, (long)off, SEEK_SET) != 0) return 0;
    return fread(buf, 1, len, f) == len;
}

int main(int argc, char **argv) {
    FILE *f;
    long size;
    unsigned char *out = NULL;
    unsigned n = 0;
    int kind = 0;
    if (argc < 2) return 2;
    f = fopen(argv[1], "rb");
    if (!f) { printf("FAIL open\n"); return 1; }
    fseek(f, 0, SEEK_END); size = ftell(f);
    if (!vz_extract_thumb(f, rd, (unsigned long long)size, &out, &n, &kind)) {
        printf("NOTHUMB %s\n", argv[1]);
        fclose(f);
        return 1;
    }
    printf("OK %s kind=%s bytes=%u\n", argv[1], kind == 1 ? "png" : "jpeg", n);
    if (argc > 2) { FILE *o = fopen(argv[2], "wb"); fwrite(out, 1, n, o); fclose(o); }
    free(out);
    fclose(f);
    return 0;
}
