#!/bin/sh
# Cross-compile on Linux:  apt install mingw-w64  &&  sh build.sh
set -e
x86_64-w64-mingw32-g++ -O2 -s -shared -o VRoidThumbs.dll thumbprov.cpp vzip.c vglb.c vjson.c miniz_tinfl.c \
  -DMINIZ_NO_STDIO -DUNICODE -D_UNICODE -static-libgcc -static-libstdc++ \
  -Wl,--kill-at thumbprov.def -lole32 -loleaut32 -luuid -lshlwapi -lwindowscodecs -lgdi32
x86_64-w64-mingw32-windres -c 65001 setup.rc -O coff -o setup.res
x86_64-w64-mingw32-gcc -O2 -s -municode -mwindows -o VRoidThumbsSetup.exe vtsetup.c setup.res \
  -DUNICODE -D_UNICODE -lshlwapi -lole32 -lshell32 -lgdi32 -luser32 -ladvapi32
echo done
