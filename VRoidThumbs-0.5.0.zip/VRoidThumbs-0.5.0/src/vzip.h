/* vzip.h - minimal, read-only ZIP reader that pulls thumbnails/thumbnail.* out of
   VRoid .vroid / .vroidcustomitem containers.  Portable C, no platform calls. */
#ifndef VZIP_H
#define VZIP_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Read `len` bytes at absolute offset `off`. Return 1 on success, 0 on failure. */
typedef int (*vz_read_fn)(void *ctx, unsigned long long off, void *buf, unsigned len);

enum { VZ_KIND_UNKNOWN = 0, VZ_KIND_PNG = 1, VZ_KIND_JPEG = 2 };

/* Hard guards - a malformed or hostile file must never make us allocate wildly. */
#define VZ_MAX_CDIR   (8u * 1024u * 1024u)   /* central directory                */
#define VZ_MAX_THUMB  (32u * 1024u * 1024u)  /* decompressed thumbnail           */

/* On success returns 1, sets *out to a malloc'd buffer (caller frees), *outlen,
   and *kind. Returns 0 on any failure. Never partially writes *out. */
/* ZIP containers: .vroid, .vroidcustomitem, .xwear, .xavatar */
int vz_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                     unsigned char **out, unsigned *outlen, int *kind);

/* glTF binary containers: .vrm */
int vg_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                     unsigned char **out, unsigned *outlen, int *kind);

/* Picks the right one by sniffing the first bytes - extension is not trusted. */
int v_extract_thumb(void *ctx, vz_read_fn rd, unsigned long long filesize,
                    unsigned char **out, unsigned *outlen, int *kind);

#ifdef __cplusplus
}
#endif
#endif
